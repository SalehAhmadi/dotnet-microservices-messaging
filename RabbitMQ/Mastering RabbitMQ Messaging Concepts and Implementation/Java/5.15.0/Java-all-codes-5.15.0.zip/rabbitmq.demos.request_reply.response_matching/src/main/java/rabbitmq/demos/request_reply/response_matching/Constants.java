package rabbitmq.demos.request_reply.response_matching;

public class Constants {
	public static final String RequestIdHeaderKey = "RequestId";
}
