package rabbitmq.demos.request_reply.response_matching;

public enum OperationType {
	Add,
    Subtract
}
