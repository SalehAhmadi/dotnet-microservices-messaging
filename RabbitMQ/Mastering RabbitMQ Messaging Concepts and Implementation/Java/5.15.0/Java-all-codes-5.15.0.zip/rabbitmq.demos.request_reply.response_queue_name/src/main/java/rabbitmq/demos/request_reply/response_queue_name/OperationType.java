package rabbitmq.demos.request_reply.response_queue_name;

public enum OperationType {
	Add,
    Subtract
}
