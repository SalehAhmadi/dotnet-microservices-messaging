package rabbitmq.demos.request_reply.response_queue_name;

public class Constants {
	public static final String RequestIdHeaderKey = "RequestId";
	public static final String ResponseQueueHeaderKey = "ResponseQueue";
}
